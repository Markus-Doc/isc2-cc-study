Cyber Tiny Planet Reference Pack

Generated image references for recreating a whimsical cyber tiny-planet diorama in Blender or similar 3D tools.

Suggested use:
- 00 original hero concept: overall art direction
- 01 front hero reference: main modelling composition
- 02 rear three-quarter reference: alternate rotation
- 03 top-down layout reference: biome placement and paths
- 04 underside reference: lower rim and underside details
- 05 dramatic bottom reference: mechanical underside, cables, glowing ports
