# Lucien-Inspired Visual System

Source reviewed: https://www.lucien.com/

## Tokens

```css
:root {
  --bg:      oklch(9% 0.018 245);
  --surface: oklch(15% 0.025 245);
  --fg:      oklch(95% 0.012 230);
  --muted:   oklch(68% 0.035 235);
  --border:  oklch(30% 0.04 240);
  --accent:  oklch(72% 0.17 220);

  --font-display: 'Arial Narrow', 'Roboto Condensed', 'Helvetica Neue Condensed', Impact, sans-serif;
  --font-body:    -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
  --font-mono:    'JetBrains Mono', 'IBM Plex Mono', ui-monospace, Menlo, monospace;
}
```

## Layout Posture

- Dark, high-contrast product-security atmosphere with cyan/blue light as a scarce accent.
- Big statement hero with proof metrics visible immediately, then stacked mission/problem/solution sections.
- Data visuals should feel active: scanlines, numeric streams, oscilloscope-style borders, and dashboard fragments.
- Use uppercase mono labels for state, progress, category, and telemetry.
- Prefer sharp panels and thin borders over soft cards; radii stay restrained and shadows become glows.

## Feature Translation

- Lucien's AI firewall becomes an exam-readiness control room.
- Real-time anomaly detection becomes weak-area detection across domains, missed questions, and review piles.
- Cryptographic/performance proof points become study metrics: domains, drill cards, quiz questions, review signals.
- Dashboard transformation section becomes interactive study dashboard and two preserved launch paths: drill and quiz.
